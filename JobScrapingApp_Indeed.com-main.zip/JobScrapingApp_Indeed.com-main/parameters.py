"""
all required arguments for the program: parameters for the search
"""

# list of any chosen key-words
positions = ["auditor"]

