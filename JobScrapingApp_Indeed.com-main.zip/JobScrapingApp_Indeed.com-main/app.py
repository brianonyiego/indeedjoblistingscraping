from parameters import positions
from main import ScrapingSession

session = ScrapingSession(positions)

if __name__ == "__main__":
    session.run()
